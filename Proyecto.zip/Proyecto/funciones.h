#define MAX_EQUIPOS 100
#define MAX_NOMBRE 50

int mostrarMenu();
void Equipo(char nombres[MAX_EQUIPOS][MAX_NOMBRE], int *cantidades, int *cantidadesBueno, int *cantidadesMalo, int *cantidadesNecesarias, float *precios, int *numEquipos);
void abrirInventario(char nombres[MAX_EQUIPOS][MAX_NOMBRE], int *cantidades, int *cantidadesBueno, int *cantidadesMalo, int *cantidadesNecesarias, float *precios, int numEquipos);
void InversionTotal(char nombres[MAX_EQUIPOS][MAX_NOMBRE], int *cantidadesMalo, int *cantidadesNecesarias, float *precios, int numEquipos);
void cargarInventario(char nombres[MAX_EQUIPOS][MAX_NOMBRE], int *cantidades, int *cantidadesBueno, int *cantidadesMalo, int *cantidadesNecesarias, float *precios, int *numEquipos);
void guardarInventario(char nombres[MAX_EQUIPOS][MAX_NOMBRE], int *cantidades, int *cantidadesBueno, int *cantidadesMalo, int *cantidadesNecesarias, float *precios, int numEquipos);

